# Monaco isolated engineering handoff

Read CHECKPOINT.md first. RELEASE HOLD. No remote code was pushed.

Published PR112: 2bb9b1e1766a93fbb8b9cf97df98050964a9d3aa
Published PR114/base: 69697ed74fb1894cea48a1b870e4d55b7b2c397c
Tested local code: 767e2209e9e623b78f6c806df3e191d9a0c218ff
Documentation successor: 7bca7eba096db3852f09093cdf786d062a11d784

patches/0000 is candidate-to-PR114 review context, NOT a git-am patch.
patches/0001 through 0005 apply in order to exact PR114 in a disposable checkout.
Do not apply 0000 again when starting from PR114. git am may produce different commit
IDs; compare the resulting tree and independently verify before integration.
The designated sole builder must reconcile claim6182330717 and current heads first.
No command here authorises a push, staging persistence, live provider call or deployment.

SQL uses PGlite0.5.10/PostgreSQL18.6, not hosted PostgreSQL17.6. Retain fixture
expectations. all.mjs tests seven fixtures plus the blocked pg_cron case. run.mjs
expects an adjacent monaco-audit repository; adjust only that checkout location if
needed. npm ci in sql-lab installs its isolated dependencies. The recorded all-run
pilot failure was an absent prerequisite private schema, fixed in the runner; the
unchanged pilot fixture passes in sql-pilot-standalone.jsonl. pg_cron remains absent.

Expected red evidence is preserved: candidate duplicate-email fixture23505,
production catalog cancellation regression, and pre-repair test failures.
Scorer empty-output controls are synthetic bookkeeping; they are not model accuracy.
The hosted raster recheck was blocked by automatic review; no response captured.

SHA256SUMS covers every delivered file except itself.
