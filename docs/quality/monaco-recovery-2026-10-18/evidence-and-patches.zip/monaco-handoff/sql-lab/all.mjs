import { PGlite } from '@electric-sql/pglite';
import { pgcrypto } from '@electric-sql/pglite/contrib/pgcrypto';
import { readFile } from 'node:fs/promises';
const root=new URL('../monaco-audit/',import.meta.url);
const read=p=>readFile(new URL(p,root),'utf8');
const base=['202608220001_pocket_founding_650.sql'];
const firstFree=['20261011164435_pocket_first_free.sql','20261011173924_pocket_first_free_claim_guards.sql','20261011175016_pocket_first_free_interrupted.sql'];
const jobs={
 'pocket-founding-subscription-isolation':[...base,'20261013163500_isolate_pocket_founding_subscriptions.sql'],
 'pocket-test-spend-ledger':['20261009191944_pocket_test_spend_reservations.sql'],
 'pocket-test-provider-receipts':['20261009191944_pocket_test_spend_reservations.sql','20261010172018_pocket_test_provider_receipts.sql'],
 'pocket-first-free':firstFree,
 'pocket-first-free-cache':[...firstFree,'20261011180804_pocket_first_free_cache_retention.sql'],
 'pocket-apple-ownership-events':['20261011165326_pocket_apple_ownership_events.sql'],
 'pocket-scan-entitlements':[...base,'20261010173440_pocket_scan_entitlements.sql','20261014143000_bind_pocket_web_subscription_identity.sql'],
 'pocket-benchmark-pilot':['20261014113000_pocket_benchmark_pilot.sql'],
};
for(const [name,migrations] of Object.entries(jobs).filter(([name])=>!process.argv[2] || name===process.argv[2])){
 const db=new PGlite({extensions:{pgcrypto}});
 await db.exec(`create role anon; create role authenticated; create role service_role;
 create schema auth; create schema private; grant usage on schema private to service_role; create schema extensions; create extension pgcrypto with schema extensions;
 create table auth.users(id uuid primary key,email text,email_confirmed_at timestamptz,is_anonymous boolean default false,is_sso_user boolean default false not null,banned_until timestamptz);
 create unique index users_email_partial_key on auth.users(email) where (is_sso_user=false);`);
 await db.exec('BEGIN');
 try {
  for(const m of migrations) await db.exec(await read('supabase/migrations/'+m));
  const results=await db.exec(await read('tests/sql/'+name+'.sql'));
  console.log(JSON.stringify({name,status:'PASS',results:results.filter(r=>r.rows.length)}));
 }catch(e){console.log(JSON.stringify({name,status:'FAIL',code:e.code,message:e.message,where:e.where,detail:e.detail}));}
 finally{await db.exec('ROLLBACK');}
 console.log(JSON.stringify({name,rollback:await db.query("select (select count(*) from auth.users) as auth_rows,(select count(*) from information_schema.tables where table_schema in ('private','public')) as remaining_tables")}));
 await db.close();
}
