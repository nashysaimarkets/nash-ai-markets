import { PGlite } from '@electric-sql/pglite';
import { readFile } from 'node:fs/promises';
for(const environment of ['production','staging']) {
 const db=new PGlite();
 await db.exec('create role anon; create role authenticated; create role service_role; BEGIN;');
 try {
  await db.exec(await readFile(new URL('../monaco-audit/supabase/migrations/202608220001_pocket_founding_650.sql',import.meta.url),'utf8'));
  await db.exec(await readFile(new URL(environment+'-function.sql',import.meta.url),'utf8'));
  await db.exec(await readFile(new URL('../monaco-audit/tests/sql/pocket-founding-subscription-isolation.sql',import.meta.url),'utf8'));
  console.log(JSON.stringify({environment,execution:'isolated PGlite only',status:'PASS'}));
 }catch(e){ console.log(JSON.stringify({environment,execution:'isolated PGlite only',status:'FAIL',code:e.code,message:e.message})); }
 finally{await db.exec('ROLLBACK');}
 console.log(JSON.stringify({environment,rollback:(await db.query("select to_regclass('public.pocket_founding_members') as table_after_rollback")).rows}));
 await db.close();
}
