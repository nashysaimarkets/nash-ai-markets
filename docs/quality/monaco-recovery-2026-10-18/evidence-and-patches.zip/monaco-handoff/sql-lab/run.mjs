import { PGlite } from '@electric-sql/pglite';
import { pgcrypto } from '@electric-sql/pglite/contrib/pgcrypto';
import { readFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
const root=new URL('../monaco-audit/',import.meta.url);
const db=new PGlite({extensions:{pgcrypto}});
const read=p=>readFile(new URL(p,root),'utf8');
await db.exec(`create role anon; create role authenticated; create role service_role;
create schema auth; create schema extensions; create extension pgcrypto with schema extensions; create schema private; grant usage on schema private to service_role;
create table auth.users(id uuid primary key,email text,email_confirmed_at timestamptz,is_anonymous boolean default false,is_sso_user boolean default false not null,banned_until timestamptz);
create unique index users_email_partial_key on auth.users(email) where (is_sso_user=false);`);
console.log(JSON.stringify({engine:await db.query('select version()')}));
for(const p of ['supabase/migrations/202608220001_pocket_founding_650.sql','supabase/migrations/20261013163500_isolate_pocket_founding_subscriptions.sql','supabase/migrations/20261010173440_pocket_scan_entitlements.sql']) await db.exec(await read(p));
const migration=await read('supabase/migrations/20261014143000_bind_pocket_web_subscription_identity.sql');
const legacy=execFileSync('git',['show','2bb9b1e1766a93fbb8b9cf97df98050964a9d3aa:tests/sql/pocket-scan-entitlements.sql'],{cwd:root,encoding:'utf8'});
for(const [name,fixture] of [['candidate112',legacy],['prepared114',await read('tests/sql/pocket-scan-entitlements.sql')]]){
 await db.exec('BEGIN');
 try{await db.exec(migration); const result=await db.exec(fixture); console.log(JSON.stringify({name,status:'PASS',result}));}
 catch(e){console.log(JSON.stringify({name,status:'FAIL',code:e.code,message:e.message,detail:e.detail,where:e.where}));}
 finally{await db.exec('ROLLBACK');}
 console.log(JSON.stringify({name,rollback:await db.query("select to_regclass('private.pocket_web_identities') as identity_table,(select count(*) from auth.users) as auth_rows")}));
}
await db.exec('BEGIN');
try{await db.exec(await read('supabase/migrations/20261014113000_pocket_benchmark_pilot.sql')); console.log(JSON.stringify({name:'pilot',status:'PASS',result:await db.exec(await read('tests/sql/pocket-benchmark-pilot.sql'))}));}
catch(e){console.log(JSON.stringify({name:'pilot',status:'FAIL',code:e.code,message:e.message,where:e.where}));}
finally{await db.exec('ROLLBACK');}
console.log(JSON.stringify({pilotRollback:await db.query("select to_regclass('private.pocket_benchmark_pilot_ledgers') as pilot")}));
await db.close();
